// Details.jsx
import React, { useEffect, useState } from 'react';
import { Button, Card } from 'react-bootstrap';
import {Link, useLocation} from 'react-router-dom';
import {useDog} from "../api/dogsHandler";

function Details() {
    const {state} = useLocation();
    const [myDog] = useDog(state.id);

    const [name,setName] = useState();
    const [age,setAge] = useState();
    const [breed,setBreed] = useState();

    useEffect(()=>{
        setName(myDog?.name);
        setAge(myDog?.age);
        setBreed(myDog?.breed);

    },[myDog])


    return (

        <div style={{ margin: "10rem" }}>
            <Card style={{ width: '18rem' }}>
                <Card.Body>
                    <Card.Title>{name}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">Age: {age}</Card.Subtitle>
                    <Card.Text>
                        Breed: {breed}
                    </Card.Text>
                    <Link to="/">
                        <Button variant="primary">Go Back</Button>
                    </Link>
                </Card.Body>
            </Card>
        </div>
    )
}

export default Details;
