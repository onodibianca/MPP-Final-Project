import React, {useState} from 'react';
import {Button,Form} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {v4 as uuid} from "uuid";
import{useNavigate} from 'react-router-dom'
import {addDog} from "../api/dogsHandler";

function Add(){
        const[name,setName] = useState('');
        const[age,setAge] = useState(0);
        const[breed,setBreed] = useState('');

        let history = useNavigate();

        const handleSubmit=(e)=>{
            e.preventDefault();
            addDog(name, age, breed)
            history("/")
        }

    return(
        <div>
            <Form className="d-grid gap-2" style={{margin:"15rem"}}>
                <Form.Group className = "mb-3" controlId="forName">
                    <Form.Control type="text" placeholder="Enter Name" required onChange={(e)=> setName(e.target.value)}>

                    </Form.Control>

                </Form.Group>
                <Form.Group className = "mb-3" controlId="forName">
                    <Form.Control type="number" placeholder="Enter Age" required onChange={(e)=> setAge(e.target.value)}>

                    </Form.Control>

                </Form.Group>
                <Form.Group className = "mb-3" controlId="forName">
                    <Form.Control type="text" placeholder="Enter Breed" required onChange={(e)=> setBreed(e.target.value)}>

                    </Form.Control>

                </Form.Group>
                <Button onClick={handleSubmit} type="submit">SUBMIT</Button>

            </Form>
        </div>
    )
}

export default Add;