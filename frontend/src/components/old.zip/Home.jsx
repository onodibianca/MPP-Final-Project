import React, {Fragment, useEffect, useState} from "react";
import {Button, Table} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Dogs from "./Dogs";
import {} from 'react-router-dom';
import {Link, useNavigate} from 'react-router-dom'
import InputGroup from 'react-bootstrap/InputGroup';
import {deleteDog, useDogs} from "../api/dogsHandler";

function Home() {

    let history = useNavigate();
    const [selectedDogs, setSelectedDogs] = useState([]);
    const [myDogs, setRefetch] = useDogs();
    const [refresher, setRefresher] = useState(false);
    let navigate = useNavigate();
    const handleEdit = (id) => {
        navigate(`/edit`, {state: {id}});
    };

    const handleViewDetails = (id) => {
        navigate(`/details`, {state: {id}});
    };


    useEffect(() => {
        history("/")
    }, [refresher]);
    const handleSelection = (id) => {
        if (!selectedDogs.includes(id)) {
            setSelectedDogs([...selectedDogs, id])
        } else {
            const filteredSelectedDogs = selectedDogs.filter(dogId => dogId !== id)
            setSelectedDogs(filteredSelectedDogs)
        }
    }

    const handleDelete = (id) => {
        deleteDog(id);
        setRefetch(true);

        console.log('delete');
    }

    const myDelete = (value) => {
        const index = Dogs.findIndex(dog => dog.id === value);
        Dogs.splice(index, 1);
    }

    function handleBulkDelete() {
        // for (let i = 0; i < Dogs.length; i++) {
        //     if (selectedDogs.includes(Dogs[i].id)) {
        //         myDelete(Dogs[i].id, Dogs);
        //         i--;
        //     }
        // }
        // setMyDogs([...Dogs])
    }

    return (
        <Fragment>
            <div style={{margin: "10rem"}}>
                <Table striped bordered hover size="sm">
                    <thead>
                    <tr>
                        {/*<th>*/}
                        {/*    Select*/}
                        {/*</th>*/}
                        <th>
                            Name
                        </th>
                        <th>
                            Age
                        </th>
                        <th>
                            Breed
                        </th>
                        <th>
                            Actions
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    {myDogs && myDogs.length > 0
                        ?
                        myDogs.map((item) => {
                            return (
                                <tr key={item.id}>
                                    {/*<td><InputGroup className="mb-3">*/}
                                    {/*    <InputGroup.Checkbox onClick={() => handleSelection(item.id)}*/}
                                    {/*                         aria-label="Checkbox for following text input"/>*/}
                                    {/*</InputGroup>*/}
                                    {/*</td>*/}
                                    <td>
                                        {item.name}
                                    </td>
                                    <td>
                                        {item.age}
                                    </td>
                                    <td>
                                        {item.breed}
                                    </td>
                                    <td>
                                        <Button onClick={() => handleDelete(item.id)}> DELETE</Button>
                                        <Button onClick={() => handleEdit(item.id)}> EDIT</Button>
                                        <Button onClick={() => handleViewDetails(item.id)}>VIEW DETAILS</Button>
                                    </td>
                                </tr>
                            )
                        })
                        :
                        <tr>
                            <td>"No data available"</td>
                        </tr>

                    }
                    </tbody>
                </Table>
                <br>

                </br>
                {/*<Button onClick={handleBulkDelete}>Bulk delete</Button>*/}
                <Link className='d-grid gap-2' to="/create">
                    <Button size="lg"> CREATE</Button>
                </Link>
            </div>
        </Fragment>

    )
}

export default Home;
