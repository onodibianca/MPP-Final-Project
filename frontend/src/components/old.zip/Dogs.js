let Dogs=[
    {
        id:"1",
        Name:"Max",
        Age:3,
        Breed:"Dalmatian"
    },{
        id:"2",
        Name:"Daisy",
        Age:7,
        Breed:"Daschund"
    },{
        id:"3",
        Name:"Buck",
        Age:1,
        Breed:"Husky"
    }
]

export default  Dogs;
